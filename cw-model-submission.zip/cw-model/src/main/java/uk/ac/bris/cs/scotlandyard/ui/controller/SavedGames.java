package uk.ac.bris.cs.scotlandyard.ui.controller;

import java.util.function.Consumer;

import javafx.scene.Parent;
import uk.ac.bris.cs.fxkit.Controller;
import uk.ac.bris.cs.scotlandyard.ui.ModelConfiguration;

public final class SavedGames implements Controller {

	public SavedGames(Consumer<ModelConfiguration> controller) {
		// TODO implement me
	}

	@Override
	public Parent root() {
		return null;
	}
}
